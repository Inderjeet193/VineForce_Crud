export class Country {
    CountryId : string='';
CountryName: string='';

}

