export class State {
    StateId:any;
    StateName: any;
    CountryId: any;
    CountryName:any

}
